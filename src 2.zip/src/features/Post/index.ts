import PostCard from "./ui/PostCard";

export {PostCard}