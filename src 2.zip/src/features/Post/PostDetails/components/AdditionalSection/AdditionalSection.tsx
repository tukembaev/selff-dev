import { ExampleData, FactsData, NoteData, Post } from "entities/Post";
import { Example } from "./SectionVariants/Example";
import { FactsList } from "./SectionVariants/FactsList";
import { Note } from "./SectionVariants/Note";

export const renderAdditionalSection = (
  structuredContent: Post["content"]["structuredContent"]
) => {
  return (
    <div className="space-y-4">
      {structuredContent.map((content, index) => (
        <div key={index}>
          {content.type === "Facts" && (
            <FactsList data={content.data as FactsData} />
          )}
          {content.type === "Note" && <Note data={content.data as NoteData} />}
          {content.type === "Example" && (
            <Example data={content.data as ExampleData} />
          )}
        </div>
      ))}
    </div>
  );
};
