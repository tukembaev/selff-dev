import { FactsData } from "entities/Post";
import { List, Muted, Small } from "shared/shadcn/ui/typography";

interface FactsListProps {
  data: FactsData;
}

export const FactsList = ({ data }: FactsListProps) => {
  return (
    <div>
      <Small className="mb-2">Факты</Small>
      <List>
        {data.items.map((item, i) => (
          <li key={i}>
            <Muted>{item}</Muted>
          </li>
        ))}
      </List>
    </div>
  );
};
