import { ExampleData } from "entities/Post";
import { Muted, P, Small } from "shared/shadcn/ui/typography";

interface ExampleContentProps {
  data: ExampleData;
}

export const Example = ({ data }: ExampleContentProps) => {
  return (
    <div>
      <Small className="mb-2">Примеры</Small>
      {data.items.map((item) => (
        <div className="pl-4">
          <P className="text-base font-semibold">{item.title}</P>
          <Muted className="text-base">{item.description}</Muted>
        </div>
      ))}
    </div>
  );
};
