import { NoteData } from "entities/Post";
import { Muted, Small } from "shared/shadcn/ui/typography";

interface NoteContentProps {
  data: NoteData;
}

export const Note = ({ data }: NoteContentProps) => {
  return (
    <div>
      <Small className="mb-2">Заметки</Small>
      {data.items.map((item) => (
        <div className="flex flex-col gap-4">
          <Muted className="text-base pl-4">{item}</Muted>
        </div>
      ))}
    </div>
  );
};
