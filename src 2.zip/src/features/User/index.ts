import { make_favorite } from "./model/services/user_queries";
import {FavoritePayload} from './model/types/user_payload'
export {make_favorite}
export type {FavoritePayload}