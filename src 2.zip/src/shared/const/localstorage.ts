export const AUTH_DATA = 'auth_data';

