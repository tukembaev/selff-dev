export interface User {
  id: number;
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  createdAt: string;
  rating: number;
  friends: number[];
  avatar?: string;
  bio?: string;
}