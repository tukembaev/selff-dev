import { getUser } from './model/userAPI'
import {User} from './types/user'
export {getUser}
export type {User}