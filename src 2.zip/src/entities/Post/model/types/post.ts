export interface Post {
  id: string;
  type: "article" | "quote" | "termin" | "persona";
  genre:
    | "history"
    | "mathematics"
    | "programming"
    | "philosophy"
    | "science"
    | "literature"
    | "economics"
    | "psychology"
    | "culture";
  title: string;
  content: PostContent;
  tags: string[];
  authorId: number;
  createdAt: string;
  suggestions: Suggestion[];
  rating: number;
  votes: number;
  isVerified: boolean;
}

export interface PostContent {
  definition: string; 
  source: string; 
  structuredContent: StructuredContent[];
}

export interface Suggestion {
  id: string;
  content: SuggestionContent;
  comment: string;
  authorId: number;
  status: "pending" | "accepted" | "rejected";
  createdAt: string;
}

export interface SuggestionContent {
  definition: string;
  source: string; 
  structuredContent: StructuredContent[];
}

export type StructuredContent =
  | { type: "Facts"; data: FactsData }
  | { type: "Note"; data: NoteData }
  | { type: "Example"; data: ExampleData };

export interface FactsData {
  items: string[];
}

export interface NoteData {
  items: string[];

}

export interface ExampleData {
  items:[{
  title: string;
  description: string;
  }]
}
