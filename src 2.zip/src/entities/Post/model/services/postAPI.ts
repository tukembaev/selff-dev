
import $api from "shared/api/api";
import { Post, Suggestion, SuggestionContent } from "../types/post";


/**
 * Получение списка публикаций
 * @param params - Параметры фильтрации (например, authorId)
 * @returns Промис с массивом публикаций
 */
export const getPosts = async (params?: { authorId?: number }): Promise<Post[]> => {
  const response = await $api.get("posts", { params });
  return response.data;
};

/**
 * Получение публикации по ID
 * @param id - Идентификатор публикации
 * @returns Промис с данными публикации
 */
export const getPost = async (id: string): Promise<Post> => {
  const response = await $api.get(`posts/${id}`);
  return response.data;
};

/**
 * Отправка предложения дополнения к публикации
 * @param postId - Идентификатор публикации
 * @param data - Данные предложения
 * @returns Промис с результатом отправки
 */
export const suggestPost = async (
  postId: string,
  suggestionData: { content: SuggestionContent; comment: string }
): Promise<Suggestion> => {
  const response = await fetch(`http://localhost:3000/posts/${postId}/suggestions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      id: crypto.randomUUID(),
      content: suggestionData.content,
      comment: suggestionData.comment,
      authorId: 1, // Замените на текущего пользователя из useAuth
      status: "pending",
      createdAt: new Date().toISOString(),
    }),
  });
  if (!response.ok) {
    throw new Error("Не удалось отправить предложение");
  }
  return response.json();
};

/**
 * Принятие предложения дополнения
 * @param postId - Идентификатор публикации
 * @param suggestionId - Идентификатор предложения
 * @returns Промис с результатом принятия
 */
export const acceptSuggestion = async (postId: string, suggestionId: string): Promise<void> => {
  const response = await fetch(`http://localhost:3000/posts/${postId}/suggestions/${suggestionId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ status: "accepted" }),
  });
  if (!response.ok) {
    throw new Error("Не удалось принять предложение");
  }
};