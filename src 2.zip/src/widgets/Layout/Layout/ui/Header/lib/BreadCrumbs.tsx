import { Dot } from "lucide-react";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
} from "shared/shadcn/ui/breadcrumb";

const BreadCrumbs = () => {
  return (
    <Breadcrumb className="pb-2">
      <BreadcrumbList>
        <BreadcrumbItem>
          <BreadcrumbLink href="/posts">Публикации</BreadcrumbLink>
        </BreadcrumbItem>

        <Dot />

        <BreadcrumbItem>
          <BreadcrumbLink href="/post/1">Пост</BreadcrumbLink>
        </BreadcrumbItem>
      </BreadcrumbList>
    </Breadcrumb>
  );
};

export default BreadCrumbs;
